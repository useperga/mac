// Türk Maç Rehberi — veri, filtre ve biçimlendirme mantığı.
// Veri kaynağı: MacEkran (https://macekran.com)

import AsyncStorage from '@react-native-async-storage/async-storage';

const BASE = 'https://macekran.com/api/v1/matches';
const CACHE_KEY = 'turk_mac_rehberi_cache_v1';
const CACHE_MAX_AGE_MS = 30 * 60 * 1000; // 30 dakika
const REQUEST_TIMEOUT_MS = 15000;
const DAYS_AHEAD = 7;

// Türkiye tüm yıl UTC+3 (yaz saati uygulaması yok) — sabit ofset güvenli.
const TR_OFFSET_MS = 3 * 60 * 60 * 1000;
const GUNLER = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
const AYLAR = [
  'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
  'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık',
];

// MacEkran'ın maç verisinden toplanan Türk kulüpleri (slug'lar API ile birebir).
// Avrupa maçlarında takımın ülkesi boş gelse bile bu liste sayesinde yakalanır.
export const TURKISH_TEAMS = new Set<string>([
  'alanyaspor', 'amedspor', 'antalyaspor', 'bandirmaspor', 'basaksehir',
  'batman-petrol', 'besiktas', 'bodrumspor', 'boluspor', 'bursaspor',
  'rizespor', 'erzurumspor', 'esenler-erokspor-1', 'eyupspor', 'fenerbahce',
  'galatasaray', 'gaziantep', 'genclerbirligi', 'goztepe', 'igdirspor',
  'istanbulspor', 'karagumruk', 'kasimpasa', 'kayserispor', 'keciorengucu',
  'kocaelispor', 'konyaspor', 'manisa-fk', 'mardin-1969', 'muglaspor',
  'pendikspor', 'samsunspor', 'sariyer', 'sivasspor', 'trabzonspor',
  'umraniyespor', 'vanspor', 'turkiye',
]);

// ---- Tipler ----
export type Team = {
  id?: number;
  slug?: string | null;
  name?: string | null;
  shortName?: string | null;
  country?: string | null;
  logoUrl?: string | null;
};

export type Channel = {
  id?: number;
  name?: string | null;
  shortName?: string | null;
  brandColor?: string | null;
};

export type Broadcast = {
  channel?: Channel | null;
  country?: string | null;
  sourceUrl?: string | null;
};

export type League = {
  name?: string | null;
  country?: string | null;
} | null;

export type Match = {
  id: number;
  slug?: string;
  kickoffAt: string;
  status?: string;
  home?: Team | null;
  away?: Team | null;
  league?: League;
  broadcasts?: Broadcast[] | null;
};

export type ChannelBadge = { name: string; color: string | null };

export type DaySection = { title: string; dateKey: string; data: Match[] };

// ---- Türkiye tespiti ----
// "Türkiye" ve İngilizce "Turkey" değerlerinin ikisini de yakalar.
function isTR(country?: string | null): boolean {
  if (!country) return false;
  const c = country.trim();
  if (c === 'TR') return true;
  return /rkiye|urkey/i.test(c);
}

export function isTurkishMatch(m: Match): boolean {
  try {
    if (isTR(m.league?.country)) return true;
    if (isTR(m.home?.country) || isTR(m.away?.country)) return true;
    if (m.home?.slug && TURKISH_TEAMS.has(m.home.slug)) return true;
    if (m.away?.slug && TURKISH_TEAMS.has(m.away.slug)) return true;
  } catch {
    return false;
  }
  return false;
}

// ---- Tarih / saat yardımcıları (hepsi Europe/Istanbul) ----
function pad(n: number): string {
  return n < 10 ? '0' + n : '' + n;
}

function toIst(iso: string): Date {
  return new Date(Date.parse(iso) + TR_OFFSET_MS);
}

function istNow(): Date {
  return new Date(Date.now() + TR_OFFSET_MS);
}

function ymd(d: Date): string {
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
}

export function saatStr(iso: string): string {
  const d = toIst(iso);
  return `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
}

function next7Dates(): string[] {
  const t = istNow();
  const base = Date.UTC(t.getUTCFullYear(), t.getUTCMonth(), t.getUTCDate());
  const out: string[] = [];
  for (let i = 0; i < DAYS_AHEAD; i++) {
    out.push(ymd(new Date(base + i * 86400000)));
  }
  return out;
}

function gunEtiketi(dateKey: string): string {
  const parts = dateKey.split('-').map(Number);
  const dt = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2]));
  const todayKey = ymd(istNow());
  const tomorrowKey = ymd(new Date(Date.parse(todayKey + 'T00:00:00Z') + 86400000));
  let prefix = '';
  if (dateKey === todayKey) prefix = 'Bugün · ';
  else if (dateKey === tomorrowKey) prefix = 'Yarın · ';
  return `${prefix}${parts[2]} ${AYLAR[parts[1] - 1]} ${GUNLER[dt.getUTCDay()]}`;
}

// ---- Kanal rozetleri (yalnız Türkiye yayınları) ----
export function trChannels(m: Match): ChannelBadge[] {
  const list = Array.isArray(m.broadcasts) ? m.broadcasts : [];
  const out: ChannelBadge[] = [];
  const seen = new Set<string>();
  for (const b of list) {
    if (!b || !b.channel) continue;
    if (!(b.country === 'TR' || isTR(b.country))) continue;
    const name = (b.channel.shortName || b.channel.name || '').trim();
    if (!name) continue;
    const key = name.toLocaleLowerCase('tr');
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ name, color: b.channel.brandColor || null });
  }
  return out;
}

export function takimAdi(t?: Team | null): string {
  return (t?.name || t?.shortName || 'Bilinmeyen').trim();
}

// ---- Ağ ----
async function fetchDay(date: string): Promise<Match[]> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), REQUEST_TIMEOUT_MS);
  try {
    const res = await fetch(`${BASE}?date=${date}&sport=futbol`, {
      headers: { Accept: 'application/json' },
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    return Array.isArray(data) ? data : [];
  } finally {
    clearTimeout(timer);
  }
}

// Önümüzdeki 7 günün Türk takımı maçlarını getirir (tekilleştirir + sıralar).
async function fetchTurkishMatches(): Promise<Match[]> {
  const dates = next7Dates();
  const results = await Promise.allSettled(dates.map(fetchDay));
  const anyOk = results.some((r) => r.status === 'fulfilled');
  if (!anyOk) throw new Error('Sunucuya ulaşılamadı');

  const seen = new Set<number>();
  const out: Match[] = [];
  for (const r of results) {
    if (r.status !== 'fulfilled') continue;
    for (const m of r.value) {
      if (!m || typeof m.id !== 'number' || !m.kickoffAt) continue; // bozuk kaydı atla
      if (seen.has(m.id)) continue;
      if (!isTurkishMatch(m)) continue;
      seen.add(m.id);
      out.push(m);
    }
  }
  out.sort((a, b) => Date.parse(a.kickoffAt) - Date.parse(b.kickoffAt));
  return out;
}

// ---- Önbellek ----
type CacheShape = { savedAt: number; matches: Match[] };

async function readCache(): Promise<CacheShape | null> {
  try {
    const raw = await AsyncStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || !Array.isArray(parsed.matches)) return null;
    return parsed as CacheShape;
  } catch {
    return null;
  }
}

async function writeCache(matches: Match[]): Promise<void> {
  try {
    await AsyncStorage.setItem(CACHE_KEY, JSON.stringify({ savedAt: Date.now(), matches }));
  } catch {
    // önbellek yazılamazsa sessiz geç
  }
}

export type LoadResult = {
  matches: Match[];
  offline: boolean; // ağ başarısız, önbellekten gösteriliyor
  savedAt: number | null;
};

// Ana yükleme. forceRefresh=true (aşağı çekerek yenileme) önbelleği atlar.
export async function loadMatches(forceRefresh: boolean): Promise<LoadResult> {
  if (!forceRefresh) {
    const cached = await readCache();
    if (cached && Date.now() - cached.savedAt < CACHE_MAX_AGE_MS) {
      return { matches: cached.matches, offline: false, savedAt: cached.savedAt };
    }
  }
  try {
    const matches = await fetchTurkishMatches();
    await writeCache(matches);
    return { matches, offline: false, savedAt: Date.now() };
  } catch (err) {
    const cached = await readCache();
    if (cached) {
      return { matches: cached.matches, offline: true, savedAt: cached.savedAt };
    }
    throw err;
  }
}

// ---- Arama + gruplama ----
export function filterBySearch(matches: Match[], query: string): Match[] {
  const q = query.trim().toLocaleLowerCase('tr');
  if (!q) return matches;
  return matches.filter((m) => {
    const parts = [
      takimAdi(m.home),
      takimAdi(m.away),
      m.league?.name || '',
      ...trChannels(m).map((c) => c.name),
    ];
    return parts.join(' ').toLocaleLowerCase('tr').includes(q);
  });
}

export function groupByDay(matches: Match[]): DaySection[] {
  const map = new Map<string, Match[]>();
  for (const m of matches) {
    const key = ymd(toIst(m.kickoffAt));
    const arr = map.get(key);
    if (arr) arr.push(m);
    else map.set(key, [m]);
  }
  return Array.from(map.keys())
    .sort()
    .map((dateKey) => ({
      dateKey,
      title: gunEtiketi(dateKey),
      data: map.get(dateKey)!,
    }));
}

export function savedAtStr(savedAt: number | null): string {
  if (!savedAt) return '';
  return saatStr(new Date(savedAt).toISOString());
}
