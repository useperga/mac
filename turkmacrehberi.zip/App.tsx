import { StatusBar } from 'expo-status-bar';
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Linking,
  Pressable,
  SectionList,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

import {
  filterBySearch,
  groupByDay,
  loadMatches,
  saatStr,
  savedAtStr,
  takimAdi,
  trChannels,
  type ChannelBadge,
  type Match,
} from './src/matches';

const SOURCES: { name: string; url: string }[] = [
  { name: 'TFF — Fikstür', url: 'https://www.tff.org/Default.aspx?pageID=600' },
  { name: 'Maçkolik', url: 'https://www.mackolik.com/' },
  { name: 'TRT Spor', url: 'https://www.trtspor.com.tr/yayin-akisi/trt-spor' },
  { name: 'A Spor', url: 'https://www.aspor.com.tr/yayin-akisi' },
  { name: 'beIN Sports', url: 'https://beinsports.com.tr/yayin-akisi' },
];

const MACEKRAN_URL = 'https://macekran.com';

function openLink(url: string) {
  Linking.openURL(url).catch(() => {});
}

function ChannelChip({ ch }: { ch: ChannelBadge }) {
  const bg = ch.color || '#E5E7EB';
  const fg = ch.color ? '#FFFFFF' : '#374151';
  return (
    <View style={[styles.chip, { backgroundColor: bg }]}>
      <Text style={[styles.chipText, { color: fg }]} numberOfLines={1}>
        {ch.name}
      </Text>
    </View>
  );
}

function MatchRow({ m }: { m: Match }) {
  const channels = trChannels(m);
  return (
    <View style={styles.matchRow}>
      <Text style={styles.time}>{saatStr(m.kickoffAt)}</Text>
      <View style={styles.matchBody}>
        <Text style={styles.league} numberOfLines={1}>
          {m.league?.name || 'Diğer maçlar'}
        </Text>
        <Text style={styles.teams}>
          {takimAdi(m.home)}  –  {takimAdi(m.away)}
        </Text>
        <View style={styles.badges}>
          {channels.length > 0 ? (
            channels.map((c, i) => <ChannelChip key={i} ch={c} />)
          ) : (
            <Text style={styles.noBroadcast}>Yayıncı henüz açıklanmadı</Text>
          )}
        </View>
      </View>
    </View>
  );
}

function SourcesFooter() {
  return (
    <View style={styles.footer}>
      <Text style={styles.footerTitle}>Kaynaklar — kendin doğrula</Text>
      <Text style={styles.footerHint}>
        Bir bilgiden emin değilsen asıl siteden kontrol edebilirsin.
      </Text>
      <View style={styles.linkWrap}>
        {SOURCES.map((s) => (
          <Pressable
            key={s.url}
            onPress={() => openLink(s.url)}
            accessibilityRole="link"
            accessibilityLabel={s.name}
            style={({ pressed }) => [styles.linkBtn, pressed && styles.pressed]}
          >
            <Text style={styles.linkText}>{s.name}</Text>
          </Pressable>
        ))}
      </View>
      <Pressable
        onPress={() => openLink(MACEKRAN_URL)}
        accessibilityRole="link"
        style={({ pressed }) => [styles.attribution, pressed && styles.pressed]}
      >
        <Text style={styles.attributionText}>Veri: MacEkran ↗</Text>
      </Pressable>
    </View>
  );
}

function Screen() {
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [matches, setMatches] = useState<Match[]>([]);
  const [offline, setOffline] = useState(false);
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [query, setQuery] = useState('');
  const [errMsg, setErrMsg] = useState('');

  const load = useCallback(async (force: boolean) => {
    if (force) setRefreshing(true);
    else setStatus('loading');
    try {
      const r = await loadMatches(force);
      setMatches(r.matches);
      setOffline(r.offline);
      setSavedAt(r.savedAt);
      setStatus('ready');
    } catch (e: any) {
      setErrMsg(e?.message ? String(e.message) : 'Bilinmeyen hata');
      setStatus('error');
    } finally {
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    load(false);
  }, [load]);

  const sections = useMemo(
    () => groupByDay(filterBySearch(matches, query)),
    [matches, query],
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
      <View style={styles.header}>
        <Text style={styles.title}>Türk Maç Rehberi</Text>
        <Text style={styles.subtitle}>Önümüzdeki 7 gün · Türk takımları</Text>
      </View>

      <View style={styles.searchWrap}>
        <TextInput
          style={styles.search}
          placeholder="Takım ara (Galatasaray, beIN...)"
          placeholderTextColor="#9CA3AF"
          value={query}
          onChangeText={setQuery}
          autoCorrect={false}
          returnKeyType="search"
          clearButtonMode="while-editing"
        />
      </View>

      {offline && (
        <View style={styles.offline}>
          <Text style={styles.offlineText}>
            Çevrimdışı — {savedAtStr(savedAt)}’de kaydedilen bilgiler gösteriliyor
          </Text>
        </View>
      )}

      {status === 'loading' && (
        <View style={styles.center}>
          <ActivityIndicator size="large" color="#0A4FA0" />
          <Text style={styles.centerText}>Maçlar yükleniyor…</Text>
        </View>
      )}

      {status === 'error' && (
        <View style={styles.center}>
          <Text style={styles.errorTitle}>Bağlantı kurulamadı</Text>
          <Text style={styles.centerText}>{errMsg}</Text>
          <Pressable
            onPress={() => load(true)}
            style={({ pressed }) => [styles.retryBtn, pressed && styles.pressed]}
          >
            <Text style={styles.retryText}>Tekrar dene</Text>
          </Pressable>
        </View>
      )}

      {status === 'ready' && (
        <SectionList
          sections={sections}
          keyExtractor={(m) => String(m.id)}
          renderItem={({ item }) => <MatchRow m={item} />}
          renderSectionHeader={({ section }) => (
            <Text style={styles.sectionHeader}>{section.title}</Text>
          )}
          stickySectionHeadersEnabled={false}
          refreshing={refreshing}
          onRefresh={() => load(true)}
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={
            <View style={styles.center}>
              <Text style={styles.centerText}>
                {query
                  ? 'Aramanla eşleşen maç yok.'
                  : 'Bu tarihlerde Türk takımı maçı bulunamadı.'}
              </Text>
            </View>
          }
          ListFooterComponent={<SourcesFooter />}
        />
      )}

      <StatusBar style="dark" />
    </SafeAreaView>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <Screen />
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F2F4F7' },
  header: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 4,
  },
  title: { fontSize: 24, fontWeight: '800', color: '#0B1F3A' },
  subtitle: { fontSize: 13, color: '#6B7280', marginTop: 2 },
  searchWrap: { paddingHorizontal: 16, paddingVertical: 10 },
  search: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 11,
    fontSize: 15,
    color: '#0B1F3A',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  offline: {
    backgroundColor: '#FEF3C7',
    marginHorizontal: 16,
    marginBottom: 6,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  offlineText: { color: '#92400E', fontSize: 13 },
  center: { alignItems: 'center', justifyContent: 'center', padding: 32, gap: 8 },
  centerText: { color: '#6B7280', fontSize: 14, textAlign: 'center' },
  errorTitle: { color: '#0B1F3A', fontSize: 17, fontWeight: '700' },
  retryBtn: {
    marginTop: 6,
    backgroundColor: '#0A4FA0',
    paddingHorizontal: 20,
    paddingVertical: 11,
    borderRadius: 10,
  },
  retryText: { color: '#FFFFFF', fontWeight: '700', fontSize: 15 },
  listContent: { paddingBottom: 24 },
  sectionHeader: {
    fontSize: 14,
    fontWeight: '800',
    color: '#0A4FA0',
    backgroundColor: '#F2F4F7',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 6,
  },
  matchRow: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    marginHorizontal: 16,
    marginTop: 8,
    borderRadius: 12,
    padding: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#EDEFF2',
  },
  time: {
    fontSize: 17,
    fontWeight: '800',
    color: '#0B1F3A',
    width: 52,
    paddingTop: 2,
  },
  matchBody: { flex: 1, gap: 4 },
  league: { fontSize: 12, color: '#6B7280', fontWeight: '600' },
  teams: { fontSize: 16, color: '#0B1F3A', fontWeight: '700' },
  badges: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 4 },
  chip: {
    borderRadius: 8,
    paddingHorizontal: 9,
    paddingVertical: 4,
    maxWidth: 200,
  },
  chipText: { fontSize: 12, fontWeight: '700' },
  noBroadcast: { fontSize: 12, color: '#9CA3AF', fontStyle: 'italic' },
  footer: {
    marginTop: 22,
    marginHorizontal: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
    gap: 8,
  },
  footerTitle: { fontSize: 15, fontWeight: '800', color: '#0B1F3A' },
  footerHint: { fontSize: 12, color: '#6B7280' },
  linkWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 4 },
  linkBtn: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 9,
    minHeight: 44,
    justifyContent: 'center',
  },
  linkText: { color: '#0A4FA0', fontWeight: '700', fontSize: 14 },
  attribution: { marginTop: 10, paddingVertical: 6 },
  attributionText: { color: '#6B7280', fontSize: 13, fontWeight: '600' },
  pressed: { opacity: 0.6 },
});
